=== WooCommerce Custom Order Status & Actions ===
Contributors: actualityextensions
Tags: woocommerce, orders, status, action, statuses, actions, status icons, action icons, custom order status, custom order action, email notification, action triggers
Requires at least: 3.5
Tested up to: 3.8
Author: Actuality Extensions

Allows users to manage WooCommerce order statuses, create the action button that triggers the status and set up the email notification that is sent when status is applied.

== Description ==

WooCommerce Custom Order Statuses & Actions is an extension for WooCommerce that allows users to manage the statuses that they set to their orders. If you aren't happy with the default statuses that are provided with WooCommerce, this plugin will help you set up a new status in no time. You can also set an action button which triggers the status along with an email notification as well.

This is WooCommerce 2.1 compatible.

== Usage ==

Simply upload the plugin and you're good to go. There are no options to configure - the extension just works.

== Installation ==

1. Upload the entire 'woocommerce-status-actions' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress