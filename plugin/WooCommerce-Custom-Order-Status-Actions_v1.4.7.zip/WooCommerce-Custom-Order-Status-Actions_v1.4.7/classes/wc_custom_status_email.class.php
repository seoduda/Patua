<?php

/**
 * Class for handling the emails
 */
class WC_Custom_Status_Email extends WC_Email {

    var $from_name, $from_email, $custom_info, $display_essential_info;

    function __construct($status_name, $status_slug, $heading, $subject, $from_name, $from_email, $custom_info, $display_essential_info, $custom_email_address='') {
        $this->id               = "{$status_slug}_email";
        $this->title            = __( $status_name, 'woocommerce_status_actions' );
        $this->description      = __( "This email is sent when order status is set to {$status_name}", 'woocommerce_status_actions' );

        $this->heading          = __( stripslashes($heading), 'woocommerce_status_actions' );
        $this->subject          = __( stripslashes($subject), 'woocommerce_status_actions' );

        $this->template_html    = 'wc_custom_status_email_html_template.php';
        $this->template_plain   = 'wc_custom_status_email_plain_template.php';

        //Set the email type to html for current requirements, plain text template is also available if needed later
        $this->email_type = 'html';

        $this->from_name = stripslashes($from_name);
        $this->from_email = $from_email;
        $this->custom_info = stripslashes(nl2br($custom_info));
        $this->display_essential_info = $display_essential_info;
        $this->custom_email_address = $custom_email_address;

        parent::__construct();
    }

    function trigger( $order_id, $recipient ) {
        global $woocommerce;

        if ( $order_id ) {
            $this->object = new WC_Order( $order_id );
            if($recipient == 'customer'){
                $this->recipient = $this->object->billing_email;
            } else if($recipient == 'admin'){
                $this->recipient = get_option('admin_email');
            } else if($recipient == 'custom'){
                $this->recipient = $this->custom_email_address;
            } else {
                return;
            }

            //Process shortcodes
            $shortcodes[] = '{order_date}';
            $replacements[] = date_i18n( woocommerce_date_format(), strtotime( $this->object->order_date ) );

            $shortcodes[] = '{order_number}';
            $replacements[] = $this->object->get_order_number();

            $shortcodes[] = '{order_value}';
            $replacements[] = $this->object->order_total;

            $shortcodes[] = '{billing_address}';
            $replacements[] = $this->object->get_formatted_billing_address();

            $shortcodes[] = '{shipping_address}';
            $replacements[] = $this->object->get_formatted_shipping_address();

            $customer_first_name = "";
            $customer_last_name = "";
            $customer_user_object = get_user_by('id', $this->object->customer_user);
            if($customer_user_object){
                $customer_first_name = $customer_user_object->get('first_name');
                $customer_last_name = $customer_user_object->get('last_name');
            }
            $shortcodes[] = '{customer_first_name}';
            $replacements[] = stripslashes( $customer_first_name );
            $shortcodes[] = '{customer_last_name}';
            $replacements[] = stripslashes( $customer_last_name );



            $billing_fields = get_option('wc_fields_billing');
            if ($billing_fields) {
                foreach($billing_fields as $name => $value) {
                    $billing_field_in_order = get_post_custom_values('_' . $name, $order_id);
                    if ($billing_field_in_order[0]) {
                        $shortcodes[] = '{' . $name . '}';
                        $replacements[] = $billing_field_in_order[0];
                    }
                }
            } else {
                $billing_field_in_order = get_post_custom_values('_billing_country', $order_id);
                if ($billing_field_in_order[0]) {
                    $shortcodes[] = '{billing_country}';
                    $replacements[] = $billing_field_in_order[0];
                } else {
                    $shortcodes[] = '{billing_country}';
                    $replacements[] = '';
                }

                $billing_field_in_order = get_post_custom_values('_billing_first_name', $order_id);
                if ($billing_field_in_order[0]) {
                    $shortcodes[] = '{billing_first_name}';
                    $replacements[] = $billing_field_in_order[0];
                } else {
                    $shortcodes[] = '{billing_first_name}';
                    $replacements[] = '';
                }

                $billing_field_in_order = get_post_custom_values('_billing_last_name', $order_id);
                if ($billing_field_in_order[0]) {
                    $shortcodes[] = '{billing_last_name}';
                    $replacements[] = $billing_field_in_order[0];
                } else {
                    $shortcodes[] = '{billing_last_name}';
                    $replacements[] = '';
                }

                $billing_field_in_order = get_post_custom_values('_billing_company', $order_id);
                if ($billing_field_in_order[0]) {
                    $shortcodes[] = '{billing_company}';
                    $replacements[] = $billing_field_in_order[0];
                } else {
                    $shortcodes[] = '{billing_company}';
                    $replacements[] = '';
                }

                $billing_field_in_order = get_post_custom_values('_billing_address_1', $order_id);
                if ($billing_field_in_order[0]) {
                    $shortcodes[] = '{billing_address_1}';
                    $replacements[] = $billing_field_in_order[0];
                } else {
                    $shortcodes[] = '{billing_address_1}';
                    $replacements[] = '';
                }

                $billing_field_in_order = get_post_custom_values('_billing_address_2', $order_id);
                if ($billing_field_in_order[0]) {
                    $shortcodes[] = '{billing_address_2}';
                    $replacements[] = $billing_field_in_order[0];
                } else {
                    $shortcodes[] = '{billing_address_2}';
                    $replacements[] = '';
                }

                $billing_field_in_order = get_post_custom_values('_billing_city', $order_id);
                if ($billing_field_in_order[0]) {
                    $shortcodes[] = '{billing_city}';
                    $replacements[] = $billing_field_in_order[0];
                } else {
                    $shortcodes[] = '{billing_city}';
                    $replacements[] = '';
                }

                $billing_field_in_order = get_post_custom_values('_billing_state', $order_id);
                if ($billing_field_in_order[0]) {
                    $shortcodes[] = '{billing_state}';
                    $replacements[] = $billing_field_in_order[0];
                } else {
                    $shortcodes[] = '{billing_state}';
                    $replacements[] = '';
                }

                $billing_field_in_order = get_post_custom_values('_billing_postcode', $order_id);
                if ($billing_field_in_order[0]) {
                    $shortcodes[] = '{billing_postcode}';
                    $replacements[] = $billing_field_in_order[0];
                } else {
                    $shortcodes[] = '{billing_postcode}';
                    $replacements[] = '';
                }

                $billing_field_in_order = get_post_custom_values('_billing_email', $order_id);
                if ($billing_field_in_order[0]) {
                    $shortcodes[] = '{billing_email}';
                    $replacements[] = $billing_field_in_order[0];
                } else {
                    $shortcodes[] = '{billing_email}';
                    $replacements[] = '';
                }

                $billing_field_in_order = get_post_custom_values('_billing_phone', $order_id);
                if ($billing_field_in_order[0]) {
                    $shortcodes[] = '{billing_phone}';
                    $replacements[] = $billing_field_in_order[0];
                } else {
                    $shortcodes[] = '{billing_phone}';
                    $replacements[] = '';
                }
            }



            $shipping_fields = get_option('wc_fields_shipping');
            if ($shipping_fields) {
                foreach($shipping_fields as $name => $value) {
                    $shipping_field_in_order = get_post_custom_values('_' . $name, $order_id);
                    if ($shipping_field_in_order[0]) {
                        $shortcodes[] = '{' . $name . '}';
                        $replacements[] = $shipping_field_in_order[0];
                    }
                }
            } else {
                $shipping_field_in_order = get_post_custom_values('_shipping_country', $order_id);
                if ($shipping_field_in_order[0]) {
                    $shortcodes[] = '{shipping_country}';
                    $replacements[] = $shipping_field_in_order[0];
                } else {
                    $shortcodes[] = '{shipping_country}';
                    $replacements[] = '';
                }

                $shipping_field_in_order = get_post_custom_values('_shipping_first_name', $order_id);
                if ($shipping_field_in_order[0]) {
                    $shortcodes[] = '{shipping_first_name}';
                    $replacements[] = $shipping_field_in_order[0];
                } else {
                    $shortcodes[] = '{shipping_first_name}';
                    $replacements[] = '';
                }

                $shipping_field_in_order = get_post_custom_values('_shipping_last_name', $order_id);
                if ($shipping_field_in_order[0]) {
                    $shortcodes[] = '{shipping_last_name}';
                    $replacements[] = $shipping_field_in_order[0];
                } else {
                    $shortcodes[] = '{shipping_last_name}';
                    $replacements[] = '';
                }

                $shipping_field_in_order = get_post_custom_values('_shipping_company', $order_id);
                if ($shipping_field_in_order[0]) {
                    $shortcodes[] = '{shipping_company}';
                    $replacements[] = $shipping_field_in_order[0];
                } else {
                    $shortcodes[] = '{shipping_company}';
                    $replacements[] = '';
                }

                $shipping_field_in_order = get_post_custom_values('_shipping_address_1', $order_id);
                if ($shipping_field_in_order[0]) {
                    $shortcodes[] = '{shipping_address_1}';
                    $replacements[] = $shipping_field_in_order[0];
                } else {
                    $shortcodes[] = '{shipping_address_1}';
                    $replacements[] = '';
                }

                $shipping_field_in_order = get_post_custom_values('_shipping_address_2', $order_id);
                if ($shipping_field_in_order[0]) {
                    $shortcodes[] = '{shipping_address_2}';
                    $replacements[] = $shipping_field_in_order[0];
                } else {
                    $shortcodes[] = '{shipping_address_2}';
                    $replacements[] = '';
                }

                $shipping_field_in_order = get_post_custom_values('_shipping_city', $order_id);
                if ($shipping_field_in_order[0]) {
                    $shortcodes[] = '{shipping_city}';
                    $replacements[] = $shipping_field_in_order[0];
                } else {
                    $shortcodes[] = '{shipping_city}';
                    $replacements[] = '';
                }

                $shipping_field_in_order = get_post_custom_values('_shipping_state', $order_id);
                if ($shipping_field_in_order[0]) {
                    $shortcodes[] = '{shipping_state}';
                    $replacements[] = $shipping_field_in_order[0];
                } else {
                    $shortcodes[] = '{shipping_state}';
                    $replacements[] = '';
                }

                $shipping_field_in_order = get_post_custom_values('_shipping_postcode', $order_id);
                if ($shipping_field_in_order[0]) {
                    $shortcodes[] = '{shipping_postcode}';
                    $replacements[] = $shipping_field_in_order[0];
                } else {
                    $shortcodes[] = '{shipping_postcode}';
                    $replacements[] = '';
                }
            }



            $tracking_provider = get_post_custom_values('_tracking_provider', $order_id);
            if ($tracking_provider[0]) {
                $shortcodes[] = '{tracking_provider}';
                $replacements[] = $tracking_provider[0];
            } else {
                $shortcodes[] = '{tracking_provider}';
                $replacements[] = '';
            }

            $custom_tracking_provider = get_post_custom_values('_custom_tracking_provider', $order_id);
            if ($custom_tracking_provider[0]) {
                $shortcodes[] = '{custom_tracking_provider}';
                $replacements[] = $custom_tracking_provider[0];
            } else {
                $shortcodes[] = '{custom_tracking_provider}';
                $replacements[] = '';
            }

            $tracking_number = get_post_custom_values('_tracking_number', $order_id);
            if ($tracking_number[0]) {
                $shortcodes[] = '{tracking_number}';
                $replacements[] = $tracking_number[0];
            } else {
                $shortcodes[] = '{tracking_number}';
                $replacements[] = '';
            }

            $custom_tracking_link = get_post_custom_values('_custom_tracking_link', $order_id);
            if ($custom_tracking_link[0]) {
                $shortcodes[] = '{custom_tracking_link}';
                $replacements[] = $custom_tracking_link[0];
            } else {
                $shortcodes[] = '{custom_tracking_link}';
                $replacements[] = '';
            }

            $date_shipped = get_post_custom_values('_date_shipped', $order_id);
            if ($date_shipped[0]) {
                $shortcodes[] = '{date_shipped}';
                $replacements[] = $date_shipped[0];
            } else {
                $shortcodes[] = '{date_shipped}';
                $replacements[] = '';
            }



            $custom_fields = get_option('wc_fields_additional');
            if ($custom_fields) {
                foreach($custom_fields as $name => $value) {
                    $custom_field_in_order = get_post_custom_values($name, $order_id);
                    if ($custom_field_in_order[0]) {
                        $shortcodes[] = '{' . $name . '}';
                        $replacements[] = $custom_field_in_order[0];
                    }
                }
            }



            $this->custom_info = str_replace($shortcodes,$replacements,$this->custom_info);

            $this->heading = str_replace($shortcodes,$replacements,$this->heading);
            $this->subject = str_replace($shortcodes,$replacements,$this->subject);
        }

        //No recipient is defined
        if ( ! $this->get_recipient() )
            return;

        $this->send( $this->get_recipient(), $this->get_subject(), $this->get_content(), $this->get_headers(), $this->get_attachments() );
    }

    function get_content_html() {
        ob_start();
        extract(array(
            'order'         => $this->object,
            'email_heading' => $this->get_heading(),
            'custom_info'   => $this->custom_info,
            'display_essential_info'=> $this->display_essential_info
        ) );
        include dirname(__FILE__) . '/wc_custom_status_email_html_template.php';
        return ob_get_clean();
    }

    function get_from_address() {
        return sanitize_email( $this->from_email );
    }

    function get_from_name() {
        return wp_specialchars_decode(stripslashes($this->from_name), ENT_QUOTES);
    }
}
?>