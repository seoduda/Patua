<?php
class RequiredFieldMissingException extends Exception {
    var $missing_fields;

    function __construct($missing_fields, $message = null, $code = 0, Exception $previous=null){
        $this->missing_fields = $missing_fields;
        parent::__construct($message, $code, $previous);
    }

    function get_missing_fields(){
        return $this->missing_fields;
    }
}
?>