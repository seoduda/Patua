<?php
class WPErrorException extends Exception {
    var $error_messages;

    function __construct($error_messages, $message = null, $code = 0, Exception $previous=null){
        $this->error_messages = $error_messages;
        parent::__construct($message, $code, $previous);
    }

    function get_error_messages(){
        return $this->error_messages;
    }
}
?>