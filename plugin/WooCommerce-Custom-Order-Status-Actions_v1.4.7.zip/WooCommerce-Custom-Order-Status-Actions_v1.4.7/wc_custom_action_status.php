<?php
/**
 * Plugin Name: WooCommerce Custom Order Status & Actions
 * Plugin URI: http://actualityextensions.com/
 * Description: Allows users to manage WooCommerce order statuses, create the action button that triggers the status and set up the email notification that is sent when status is applied.
 * Version: 1.4.7
 * Author: Actuality Extensions
 * Author URI: http://actualityextensions.com/
 * Tested up to: 3.8
 *
 * Copyright: (c) 2012-2013 Actuality Extensions
 *
 * License: GNU General Public License v3.0
 * License URI: http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @package     WC-Custom-Status
 * @author      Actuality Extensions
 * @category    Plugin
 * @copyright   Copyright (c) 2012-2013, Actuality Extensions
 * @license     http://www.gnu.org/licenses/gpl-3.0.html GNU General Public License v3.0
 */
global $woocommerce_status_actions_db_version;
$woocommerce_status_actions_db_version = '1.1.1';

ini_set('zlib.output_compression','off');

add_filter('sanitize_title', 'woocommerce_status_actions_sanitize_title', 9);
add_filter('sanitize_file_name', 'woocommerce_status_actions_sanitize_title');

register_activation_hook( __FILE__, 'wc_install_db_tables' );
add_action('plugins_loaded', 'wc_custom_status_init', 0);
add_action('admin_init','add_admin_stylesheets');
add_action( 'admin_footer', 'woocommerce_status_actions_bulk', 11 );
add_action( 'load-edit.php', 'woocommerce_status_actions_bulk_handler' );

add_action( 'woocommerce_status_actions_check_db_version', 'wc_install_db_tables' );
do_action( 'woocommerce_status_actions_check_db_version' );

add_filter('woocommerce_order_is_download_permitted', 'woocommerce_status_actions_order_is_download_permitted', 10, 2);

if(wc_sa_get_woo_version() > 2.1){
    add_filter('wc_order_statuses', 'woocommerce_status_actions_wc_order_statuses', 10, 1);
    add_action( 'init', 'woocommerce_status_actions_register_post_status');
}

function woocommerce_status_actions_wc_order_statuses($statuses)
{
    global $wpdb;
    $table_name = $wpdb->prefix . "woocommerce_order_status_action";
    $query = "SELECT * FROM $table_name";
    $status_info = $wpdb->get_results($query);

    foreach ($status_info as $status) {
        $statuses['wc-'.$status->status_slug] = $status->status_name;
    }
    return $statuses;
}

function woocommerce_status_actions_register_post_status() {
    global $wpdb;
    $table_name = $wpdb->prefix . "woocommerce_order_status_action";
    $query = "SELECT * FROM $table_name";
    $status_info = $wpdb->get_results($query);

    foreach ($status_info as $status) {
        register_post_status( 'wc-'.$status->status_slug, array(
            'label'                     => $status->status_name,
            'public'                    => true,
            'exclude_from_search'       => false,
            'show_in_admin_all_list'    => true,
            'show_in_admin_status_list' => true,
            'label_count'               => _n_noop( $status->status_name.' <span class="count">(%s)</span>', $status->status_name.' <span class="count">(%s)</span>', 'woocommerce_status_actions' )
        ) );
    }

    
}

function woocommerce_action_status_compile_less( $less_file, $css_file ) {

    global $woocommerce;


        if ( ! class_exists( 'lessc' ) )
            include_once( WC()->plugin_path() . '/includes/libraries/class-lessc.php' );

        if ( ! class_exists( 'cssmin' ) )
            include_once( WC()->plugin_path() . '/includes/libraries/class-cssmin.php' );



    $less           = new lessc( $less_file );
    $compiled_css   = $less->parse();

    if ( $compiled_css )
        file_put_contents( $css_file, $compiled_css );
}

function woocommerce_status_actions_generate_action_icons() {
    ############ GENERATE CSS FILE ##################
    $font_file = plugin_dir_path( __FILE__ ) . 'css/fonts/icomoon.svg';
    if( file_exists( $font_file ) ) {
        $file = file_get_contents( $font_file );
        $matches = array();
        preg_match_all( "/glyph unicode=\"(.*?)\"/", $file, $matches);
        foreach( $matches[1] as $unicode ) {
            $class_name = str_replace('&#x', '', $unicode);
            $class_name = str_replace(';', '', $class_name);
            file_put_contents( plugin_dir_path( __FILE__ ) . '/css/action_icons.less' ,  '.woocommerce_status_actions_'. $class_name .':after {content: "\\'.$class_name.'";}' . PHP_EOL, FILE_APPEND);
        }
        // Compile Icons CSS
        $less_file = plugin_dir_path(__FILE__ ) . '/css/action_icons.less';
        $css_file = plugin_dir_path(__FILE__ ) . '/css/action_icons.css';
        woocommerce_action_status_compile_less( $less_file, $css_file );
    }
}

function woocommerce_custom_status_action_column_width_override() {
    ?>
    <script type="text/javascript">
        jQuery(document).ready(function(){
            if( jQuery('.status_text.hhh').length > 0 ) {
                jQuery('.column-order_status').css( 'width', '80px' );
            }
            else if ( jQuery('.status_line_text.hhh').length > 0 ) {
                jQuery('.column-order_status').css( 'width', '80px' );
            }
        });
    </script>
    <?php
}

/**
 * Adds the plugin's stylesheets to the dashboard
 */
function add_admin_stylesheets() {
    global $woocommerce;
    // Ensure our specific CSS is loaded only on our pages so as to not affect other pages
    if( (isset( $_GET['page'] ) && strpos( $_GET['page'], 'woocommerce_status_and_actions') != -1) || ( isset($_GET['post_type']) && strpos( $_GET['post_type'], 'shop_order') != -1) ) {
        add_action( 'admin_footer',  'woocommerce_custom_status_action_column_width_override' );
    }


    if( !file_exists( plugin_dir_path(__FILE__ ) . '/css/action_icons.less' ) )
        woocommerce_status_actions_generate_action_icons();

    $action_icons_file_url = plugin_dir_url(__FILE__) . '/css/action_icons.css';


    if( !file_exists( plugin_dir_path(__FILE__ ) . '/css/admin.css' ) ) {
        // Compile Admin CSS
        $less_file = plugin_dir_path(__FILE__ ) . '/css/admin.less';
        $css_file = plugin_dir_path(__FILE__ ) . '/css/admin.css';
        woocommerce_action_status_compile_less( $less_file, $css_file );

    }

    $css_file_url = plugin_dir_url(__FILE__) . '/css/admin.css';

    wp_enqueue_style('status_actions_less', $css_file_url );
    wp_enqueue_style('status_actions_less_icons_test', $action_icons_file_url );

    wp_register_style( 'woocommerce_frontend_styles', plugins_url() . '/woocommerce/assets/css/admin.css' );
    wp_enqueue_style( 'woocommerce_frontend_styles' );


    wp_register_script( 'woocommerce_tiptip_js', plugins_url() . '/woocommerce/assets/js/jquery-tiptip/jquery.tipTip.min.js' );
    wp_enqueue_script( 'woocommerce_tiptip_js' );


    wp_enqueue_style('wp-color-picker');
    wp_enqueue_script('wp-color-picker');


    wp_enqueue_script(
        'jquery-validate',
        plugin_dir_url( __FILE__ ) . 'js/jquery.validate.min.js',
        array('jquery'),
        '1.11.0',
        true
    );
    wp_enqueue_script('media-upload');
    wp_enqueue_script(
        'retina',
        plugin_dir_url( __FILE__ ) . 'js/retina.js',
        '0.0.2',
        true
    );
    wp_enqueue_script(
        'shortcodes',
        plugin_dir_url( __FILE__ ) . 'js/shortcodes.js',
        array('jquery'),
        true
    );
    // Handles the deletion of the statuses
    wp_enqueue_script( 'delete-custom-scripts', plugin_dir_url(__FILE__) . 'js/custom-status-action-delete.js', array('jquery') );

    /**************** iconpicker *******************/
    if(isset($_GET['page']) && $_GET['page'] == 'woocommerce_status_and_actions'){
        wp_register_style( 'iconpicker_styles', plugin_dir_url(__FILE__ ) . 'css/fontawesome-iconpicker.css' );
        wp_enqueue_style( 'iconpicker_styles' );

        wp_register_script( 'bootstrap_js', plugin_dir_url(__FILE__ ) .  'js/bootstrap.js', array('jquery') );
        wp_enqueue_script( 'bootstrap_js' );

        
        wp_register_script( 'iconpicker', plugin_dir_url(__FILE__ ) .  'js/fontawesome-iconpicker.js', array('jquery') );
        wp_enqueue_script( 'iconpicker' );

        wp_register_script( 'woocommerce_status_and_actions_scripts', plugin_dir_url(__FILE__ ) .  'js/js.js', array('jquery', 'bootstrap_js') );
        wp_enqueue_script( 'woocommerce_status_and_actions_scripts' );


        wp_localize_script( 'woocommerce_status_and_actions_scripts', 'wc_sa_icons_array', woocommerce_status_and_actions_generate_icons_array_from_img() );
    }
    /**************** /iconpicker *******************/
}

function woocommerce_status_and_actions_generate_icons_array_from_img( ) {
        global $woocommerce;
        $display = array();
            // Version 2.1 Icons
            $font_file = plugin_dir_path( __FILE__ ) . 'css/fonts/icomoon.svg';
            if( file_exists( $font_file ) ) {
                $file = file_get_contents( $font_file );
                $matches = array();
                preg_match_all( "/glyph unicode=\"(.*?)\"/", $file, $matches);
                foreach( $matches[1] as $unicode ) {
                    $class_name = str_replace('&#x', '', $unicode);
                    $class_name = str_replace(';', '', $class_name);
                    if( $class_name == '20') continue;
                    $display[] = $class_name;
                }
            }
        return $display;
    }

/**
 * Registers the hooks required for the plugin
 * @return void
 */
function wc_custom_status_init() {
    if ( !in_array( 'woocommerce/woocommerce.php', apply_filters( 'active_plugins', get_option( 'active_plugins' ) ) ) ) {
        return;
    }
    global $woocommerce;

    // Email handling
    define( 'WC_CUSTOM_STATUS_PLUGIN_PATH', plugin_dir_url(__FILE__) );

    // Localization domain
    load_plugin_textdomain('woocommerce_status_actions', false, dirname( plugin_basename( __FILE__ ) ) . '/languages');

    // The core of the plugin
    $GLOBALS['wc_custom_status_object'] = new WC_Custom_Status_Plugin();

    // Adds the action hook for when the action button is clicked from the orders table (action column)
    $action_list = WC_Custom_Status::get_status_list();
    add_action("wp_ajax_woocommerce_mark_order_as_custom_status", 'process_custom_action');
    add_action('admin_notices', 'wc_custom_order_bulk_admin_notices' );
}


/**
 * Adds the admin messages on successful changes/update of our custom actions/statuses
 * @return [type] [description]
 */
function wc_custom_order_bulk_admin_notices() {
    global $post_type, $pagenow;

    if (isset($_REQUEST['order_status_changed'])) {
        $number = absint( $_REQUEST['order_status_changed'] );
        $message_title = __('Order status Changed','woocommerce_status_actions');
    } else {
        return;
    }

    if ( 'edit.php' == $pagenow && 'shop_order' == $post_type ) {
        $message = sprintf( __( $message_title . '. %s orders affected.', $number, 'woocommerce_status_actions' ), number_format_i18n( $number ) );
        echo '<div class="updated"><p>' . $message . '</p></div>';
    }
}

function woocommerce_status_actions_bulk() {
   global $post_type;
   $status_list       = WC_Custom_Status::$default_status_list;
   $status_list_names = WC_Custom_Status::get_status_list_names();
   unset($status_list[array_search('processing',$status_list)]);
   unset($status_list[array_search('completed',$status_list)]);
   unset($status_list[array_search('on-hold',$status_list)]);
   asort($status_list);


   if ( 'shop_order' == $post_type ) {
       ?>
       <script type="text/javascript">
           jQuery(document).ready(function() {
               jQuery('.custom_payment_status').each(function(){jQuery(this).parent().parent().css('background-color',jQuery(this).attr('rowcolor'));});
               <?php foreach($status_list as $status_slug){ ?>
                    jQuery('<option>').val('mark_custom_status_<?php echo $status_slug; ?>')
                        .text('<?php _e( "Mark", "woocommerce_status_actions" ) ?> <?php echo $status_slug; ?>').appendTo('select[name=action]');
                    jQuery('<option>').val('mark_custom_status_<?php echo $status_slug; ?>')
                        .text('<?php _e( "Mark", "woocommerce_status_actions" ) ?> <?php echo $status_slug; ?>').appendTo('select[name=action2]');
                <?php
               }
               foreach($status_list_names as $status_slug => $name){ ?>
                   jQuery('<option>').val('mark_custom_status_<?php echo $status_slug; ?>')
                        .text('<?php _e( "Mark", "woocommerce_status_actions" ) ?> <?php echo mb_strtolower($name); ?>').appendTo('select[name=action]');
                   jQuery('<option>').val('mark_custom_status_<?php echo $status_slug; ?>')
                        .text('<?php _e( "Mark", "woocommerce_status_actions" ) ?> <?php echo mb_strtolower($name); ?>').appendTo('select[name=action2]');
               <?php
               }
               ?>
            });
        </script>
        <?php
    }
}

function woocommerce_status_actions_bulk_handler() {
    if(!isset($_REQUEST['post'])){
        return;
    }
    $wp_list_table = _get_list_table( 'WP_Posts_List_Table' );
    $action = $wp_list_table->current_action();
    #print_r($action);

    $changed = 0;
    $post_ids = array_map( 'absint', (array) $_REQUEST['post'] );
    if(strstr($action,'mark_custom_status')) {
       $new_status = substr($action,strlen('mark_custom_status_'));
       $report_action = "order_status_changed";
       foreach( $post_ids as $post_id ) {
           $order = new WC_Order($post_id);
           $order->update_status( $new_status );
           $changed++;
       }
    } else{
        return;
    }
    $sendback = add_query_arg( array( 'post_type' => 'shop_order', $report_action => $changed, 'ids' => join( ',', $post_ids ) ), '' );
    wp_redirect( $sendback );
    exit();
}


/**
 * Processes the custom action to mark an order with our custom status
 * @return void
 */
function process_custom_action(){
    
    if(isset($_REQUEST['custom_action_name']) && !empty($_REQUEST['custom_action_name']) ){
        $action_name = $_REQUEST['custom_action_name'];
        
        if ( !current_user_can('edit_shop_orders') )
            wp_die( __( 'You do not have sufficient permissions to access this page.', 'woocommerce' ) );
        if ( !check_admin_referer("woocommerce-mark-order-{$action_name}"))
            wp_die( __( 'You have taken too long. Please go back and retry.', 'woocommerce' ) );
        
        $order_id = isset($_REQUEST['order_id']) && (int) $_REQUEST['order_id'] ? (int) $_REQUEST['order_id'] : '';
        if (!$order_id) die;
        
        $wc_custom_action = new WC_Custom_Status();

        $test = $wc_custom_action->load_status_from_db($action_name);
        
        if( $test ){
            $order = new WC_Order( $order_id );
            if($order)
                $order->update_status( $action_name );
        }
        
    }

    wp_safe_redirect( wp_get_referer() );
    die();
}

function woocommerce_status_actions_sanitize_title($title) {
    global $wpdb;

    $iso9_table = array(
        'А' => 'A', 'Б' => 'B', 'В' => 'V', 'Г' => 'G', 'Ѓ' => 'G',
        'Ґ' => 'G', 'Д' => 'D', 'Е' => 'E', 'Ё' => 'YO', 'Є' => 'YE',
        'Ж' => 'ZH', 'З' => 'Z', 'Ѕ' => 'Z', 'И' => 'I', 'Й' => 'J',
        'Ј' => 'J', 'І' => 'I', 'Ї' => 'YI', 'К' => 'K', 'Ќ' => 'K',
        'Л' => 'L', 'Љ' => 'L', 'М' => 'M', 'Н' => 'N', 'Њ' => 'N',
        'О' => 'O', 'П' => 'P', 'Р' => 'R', 'С' => 'S', 'Т' => 'T',
        'У' => 'U', 'Ў' => 'U', 'Ф' => 'F', 'Х' => 'H', 'Ц' => 'TS',
        'Ч' => 'CH', 'Џ' => 'DH', 'Ш' => 'SH', 'Щ' => 'SHH', 'Ъ' => '',
        'Ы' => 'Y', 'Ь' => '', 'Э' => 'E', 'Ю' => 'YU', 'Я' => 'YA',
        'а' => 'a', 'б' => 'b', 'в' => 'v', 'г' => 'g', 'ѓ' => 'g',
        'ґ' => 'g', 'д' => 'd', 'е' => 'e', 'ё' => 'yo', 'є' => 'ye',
        'ж' => 'zh', 'з' => 'z', 'ѕ' => 'z', 'и' => 'i', 'й' => 'j',
        'ј' => 'j', 'і' => 'i', 'ї' => 'yi', 'к' => 'k', 'ќ' => 'k',
        'л' => 'l', 'љ' => 'l', 'м' => 'm', 'н' => 'n', 'њ' => 'n',
        'о' => 'o', 'п' => 'p', 'р' => 'r', 'с' => 's', 'т' => 't',
        'у' => 'u', 'ў' => 'u', 'ф' => 'f', 'х' => 'h', 'ц' => 'ts',
        'ч' => 'ch', 'џ' => 'dh', 'ш' => 'sh', 'щ' => 'shh', 'ъ' => '',
        'ы' => 'y', 'ь' => '', 'э' => 'e', 'ю' => 'yu', 'я' => 'ya'
    );
    $geo2lat = array(
        'ა' => 'a', 'ბ' => 'b', 'გ' => 'g', 'დ' => 'd', 'ე' => 'e', 'ვ' => 'v',
        'ზ' => 'z', 'თ' => 'th', 'ი' => 'i', 'კ' => 'k', 'ლ' => 'l', 'მ' => 'm',
        'ნ' => 'n', 'ო' => 'o', 'პ' => 'p','ჟ' => 'zh','რ' => 'r','ს' => 's',
        'ტ' => 't','უ' => 'u','ფ' => 'ph','ქ' => 'q','ღ' => 'gh','ყ' => 'qh',
        'შ' => 'sh','ჩ' => 'ch','ც' => 'ts','ძ' => 'dz','წ' => 'ts','ჭ' => 'tch',
        'ხ' => 'kh','ჯ' => 'j','ჰ' => 'h'
    );
    $iso9_table = array_merge($iso9_table, $geo2lat);

    $locale = get_locale();
    switch ( $locale ) {
        case 'bg_BG':
            $iso9_table['Щ'] = 'SHT';
            $iso9_table['щ'] = 'sht'; 
            $iso9_table['Ъ'] = 'A';
            $iso9_table['ъ'] = 'a';
            break;
        case 'uk':
            $iso9_table['И'] = 'Y';
            $iso9_table['и'] = 'y';
            break;
        case 'uk_ua':
            $iso9_table['И'] = 'Y';
            $iso9_table['и'] = 'y';
            break;
    }

    $is_term = false;
    $backtrace = debug_backtrace();
    foreach ( $backtrace as $backtrace_entry ) {
        if ( $backtrace_entry['function'] == 'wp_insert_term' ) {
            $is_term = true;
            break;
        }
    }

    $term = $is_term ? $wpdb->get_var("SELECT slug FROM {$wpdb->terms} WHERE name = '$title'") : '';
    if ( empty($term) ) {
        $title = strtr($title, apply_filters('ctl_table', $iso9_table));
        if (function_exists('iconv')){
            $title = iconv('UTF-8', 'UTF-8//TRANSLIT//IGNORE', $title);
        }
        $title = preg_replace("/[^A-Za-z0-9'_\-\.]/", '-', $title);
        $title = preg_replace('/\-+/', '-', $title);
        $title = preg_replace('/^-+/', '', $title);
        $title = preg_replace('/-+$/', '', $title);
    } else {
        $title = $term;
    }

    return $title;
}



/**
 * On plugin's installation/activation, create our custom database tables
 * @return void
 */
function wc_install_db_tables(){
    global $wpdb, $woocommerce_status_actions_db_version;
      $wpdb->hide_errors();
      $installed_ver = get_option( "woocommerce_status_actions_db_version" );

    if( $installed_ver != $woocommerce_status_actions_db_version ){
        $table_name = $wpdb->prefix . "woocommerce_order_status_action";
        $sql = "CREATE TABLE $table_name (
                id INT NOT NULL AUTO_INCREMENT,
                term_id INT(10) NOT NULL,
                term_taxonomy_id INT(10) NOT NULL,
                created datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
                updated datetime DEFAULT '0000-00-00 00:00:00' NOT NULL,
                status_slug VARCHAR(17) NOT NULL,
                status_name VARCHAR(255) NOT NULL,
                status_label VARCHAR(55) NOT NULL,
                status_icon TEXT NOT NULL,
                status_color VARCHAR(10) NOT NULL,
                status_color_type VARCHAR(1) NOT NULL,
                sends_email VARCHAR(1) NOT NULL,
                display_completed VARCHAR(1) NOT NULL,
                display_processing VARCHAR(1) NOT NULL,
                can_cancel VARCHAR(1) NOT NULL,
                display_in_reports VARCHAR(1) NOT NULL,
                download_permitted VARCHAR(1) NOT NULL,
                email_to VARCHAR(15),
                custom_email_address VARCHAR(100),
                email_subject VARCHAR(200),
                from_name VARCHAR(200),
                from_address VARCHAR(100),
                display_essential_info VARCHAR(1) NOT NULL,
                display_custom_info VARCHAR(1) NOT NULL,
                custom_title VARCHAR(200),
                custom_info TEXT,
                payment_status VARCHAR(20),
                action_icon TEXT NOT NULL,
                display_for TEXT NOT NULL,
                new_status VARCHAR(55) NOT NULL,
                PRIMARY KEY  (id)
               );";

        error_log($sql);
        require_once( ABSPATH . 'wp-admin/includes/upgrade.php' );
        dbDelta( $sql );

         
        if(version_compare( $installed_ver, '1.0.5', '=' ) && wc_sa_get_woo_version() > 2.1 ){
            $table_name = $wpdb->prefix . "woocommerce_order_status_action";
            $query = "SELECT * FROM $table_name";
            $status_info = $wpdb->get_results($query);
            $wpdb->hide_errors();
            foreach ($status_info as $status) {
                $data = array();
                $n_slug = 'st_act_'.$status->status_icon;
                $sql = "SELECT COUNT(DISTINCT id) FROM $table_name WHERE status_slug LIKE '{$n_slug}%' AND id != {$status->id}";
                $status_count = $wpdb->get_var($sql);
                if($status_count > 0)
                    $data['status_slug'] = $n_slug.'-'.($status_count+1);
                else
                    $data['status_slug'] = $n_slug;

                $data['new_status'] = $data['status_slug'];
                $wpdb->update($table_name, $data, array('id' => $status->id));

                if(!empty($status->status_slug)){
                    $wpdb->update($table_name, array('post_status'=> 'wc-'.$n_slug), array('post_status' => 'wc-'.$status->status_slug));
                }
            }
            $installed_ver = '1.0.8';
        }
        if(version_compare( $installed_ver, '1.0.8', '=' ) && wc_sa_get_woo_version() > 2.1 ){
            $table_name = $wpdb->prefix . "woocommerce_order_status_action";
            $query = "SELECT * FROM $table_name";
            $status_info = $wpdb->get_results($query);
            $wpdb->hide_errors();
            foreach ($status_info as $status) {
                if(!empty($status->status_label)) continue;
                $data                 = array();
                $data['status_label'] = $status->status_name;
                $wpdb->update($table_name, $data, array('id' => $status->id));
            }
            $installed_ver = '1.1.0';
        }

        if(get_option( "woocommerce_status_actions_db_version" )) {
          update_option( "woocommerce_status_actions_db_version", $woocommerce_status_actions_db_version );
        }else{
          add_option( "woocommerce_status_actions_db_version", $woocommerce_status_actions_db_version );
        }
    }
}

function wc_sa_get_woo_version() {
        // If get_plugins() isn't available, require it
    if ( ! function_exists( 'get_plugins' ) )
        require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    
        // Create the plugins folder and file variables
    $plugin_folder = get_plugins( '/' . 'woocommerce' );
    $plugin_file = 'woocommerce.php';
    
    // If the plugin version number is set, return it 
    if ( isset( $plugin_folder[$plugin_file]['Version'] ) ) {
        return $plugin_folder[$plugin_file]['Version'];

    } else {
    // Otherwise return null
        return NULL;
    }
}

function woocommerce_status_actions_order_is_download_permitted($download_permitted, $class)
{
    $post_status = $class->post_status;
    $status_slug = str_replace ('wc-', '', $post_status);
    global $wpdb;
    $table_name = $wpdb->prefix . "woocommerce_order_status_action";

    $query = "SELECT * FROM $table_name WHERE status_slug = '$status_slug'";
    $status_info = $wpdb->get_row($query);
    if($status_info && !empty($status_info) && is_string($status_info->download_permitted) & $status_info->download_permitted == '1')
        return true;

    return $download_permitted;
}

require dirname(__FILE__) . '/classes/wc_custom_status_plugin.class.php';
require dirname(__FILE__) . '/classes/wc_custom_status.class.php';
require dirname(__FILE__) . '/classes/exceptions/requiredfieldmissing.class.php';
require dirname(__FILE__) . '/classes/exceptions/wperrorexception.class.php';

if(!class_exists('WP_List_Table')){
    require_once( ABSPATH . 'wp-admin/includes/class-wp-list-table.php' );
}

require dirname(__FILE__) . '/classes/tables/wc_custom_status_table.class.php';

?>
