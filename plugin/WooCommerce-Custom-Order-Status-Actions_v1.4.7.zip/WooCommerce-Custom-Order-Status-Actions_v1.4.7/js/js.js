jQuery(document).ready(function($) {
  if($('#status_icon_picker').length > 0 ){
    $('#status_icon_picker').each(function(){
      var $this = $(this);
      $this.iconpicker({
        placement:'bottomRight',
                        iconBaseClass: 'woocommerce_status_font_icon',
                        iconComponentBaseClass: 'woocommerce_status_font_icon',
                        iconClassPrefix: 'woocommerce_status_actions_',
                        container: $(' ~ .dropdown-menu:first', $this),
                        showFooter: false,
                        showHeader: false,
                        hideOnSelect: true,
                        icons : wc_sa_icons_array
                    });
    });


  $('#status_icon_picker').on('iconpickerSelected', function(e) {
    var i_val = e.iconpickerValue;
    var i_class = e.iconpickerInstance.options.iconComponentBaseClass+' '+e.iconpickerInstance.options.iconClassPrefix+i_val;
    $('#status_icon_picker_val').val(i_val);
    $('#status_icon_picker_view span').attr('class', i_class);
  });

  $('#action_icon_picker').each(function(){
      var $this = $(this);
      $this.iconpicker({
        placement:'bottomRight',
                        iconBaseClass: 'woocommerce_status_action_font_icon',
                        iconComponentBaseClass: 'woocommerce_status_action_font_icon',
                        iconClassPrefix: 'woocommerce_status_actions_',
                        container: $(' ~ .dropdown-menu:first', $this),
                        showFooter: false,
                        showHeader: false,
                        hideOnSelect: true,
                        icons : wc_sa_icons_array
                    });
    });


  $('#action_icon_picker').on('iconpickerSelected', function(e) {
    var i_val = e.iconpickerValue;
    var i_class = e.iconpickerInstance.options.iconComponentBaseClass+' '+e.iconpickerInstance.options.iconClassPrefix+i_val;
    $('#action_icon_picker_val').val(i_val);
    $('#action_icon_picker_view span').attr('class', i_class);
  });
}

});