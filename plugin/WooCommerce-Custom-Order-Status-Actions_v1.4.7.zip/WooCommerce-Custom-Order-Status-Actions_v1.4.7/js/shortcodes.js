jQuery(document).ready(function($) {
    $("#standart_shortcodes").click(function (event) {
        var shortcode = $("#standart_shortcodes :selected").val();
        var current_text = $('#custom_info').val();
        var cursorPosition = $('#custom_info').prop("selectionStart");

        var output = [current_text.slice(0, cursorPosition), shortcode, current_text.slice(cursorPosition)].join('');
        $('#custom_info').val(output);
        $('#standart_shortcodes :first-child').attr("selected","selected");
    });
    $("#billing_shortcodes").click(function (event) {
        var shortcode = $("#billing_shortcodes :selected").val();
        var current_text = $('#custom_info').val();
        var cursorPosition = $('#custom_info').prop("selectionStart");

        var output = [current_text.slice(0, cursorPosition), shortcode, current_text.slice(cursorPosition)].join('');
        $('#custom_info').val(output);
        $('#billing_shortcodes :first-child').attr("selected","selected");
    });
    $("#shipping_shortcodes").click(function (event) {
        var shortcode = $("#shipping_shortcodes :selected").val();
        var current_text = $('#custom_info').val();
        var cursorPosition = $('#custom_info').prop("selectionStart");

        var output = [current_text.slice(0, cursorPosition), shortcode, current_text.slice(cursorPosition)].join('');
        $('#custom_info').val(output);
        $('#shipping_shortcodes :first-child').attr("selected","selected");
    });
    $("#tracking_shortcodes").click(function (event) {
        var shortcode = $("#tracking_shortcodes :selected").val();
        var current_text = $('#custom_info').val();
        var cursorPosition = $('#custom_info').prop("selectionStart");

        var output = [current_text.slice(0, cursorPosition), shortcode, current_text.slice(cursorPosition)].join('');
        $('#custom_info').val(output);
        $('#tracking_shortcodes :first-child').attr("selected","selected");
    });
    $("#additional_shortcodes").click(function (event) {
        var shortcode = $("#additional_shortcodes :selected").val();
        var current_text = $('#custom_info').val();
        var cursorPosition = $('#custom_info').prop("selectionStart");

        var output = [current_text.slice(0, cursorPosition), shortcode, current_text.slice(cursorPosition)].join('');
        $('#custom_info').val(output);
        $('#additional_shortcodes :first-child').attr("selected","selected");
    });
});