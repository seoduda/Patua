function wc_delete_status(data) {
    var toReturn = '';  
    confirme = confirm('Are you sure?');
    if( confirme  == true) {
        jQuery.ajax({
            url: ajaxurl,
            type: 'POST',
            'data': data,
            async: false
        }).done(function(r){
            toReturn = r;
        });
    }
    
    return toReturn;
}

jQuery(document).ready(function($) {

    jQuery(".tips").tipTip({
        'attribute' : 'data-tip',
        'fadeIn' : 50,
        'fadeOut' : 50
    });

    jQuery(".help_tip").tipTip({
        'attribute' : 'data-tip',
        'fadeIn' : 50,
        'fadeOut' : 50
    });

$('.linen_delete_status').click(function(){
		$(this).siblings( 'select, a.button' ).toggle();
});

$('.linen_confirm').click(function(){
	data = {
            action: 'delete_custom_status',
            nonce: $(this).data('nonce'),
            delete_status_id: $('select.linen_order_statuses').data('id'),
            alt_term: $('select.linen_order_statuses').val()
        };
    returned = wc_delete_status( data );
    if( returned == '1' ) {
        window.location = $('a.linen_confirm').data('url');
    } else if( returned == '-1' ) {
        alert('Please choose another alternative term for all statuses. Refresh this page and try again');
    } else {
        alert('An error occurred. Please try again.');
    }
});

$('#cb-select-all-1, #cb-select-all-2').click(function(){
    st = $(this).attr('checked');
    if( st == 'checked' ) {
        $('input[name="status_id[]"]').attr('checked', st);
    } else {
        $('input[name="status_id[]"]').removeAttr('checked');
    }
});

$('.linen_confirm_multi').click(function(){
    data = {
            action: 'delete_custom_status',
            nonce: $(this).data('nonce'),
            status_id: $('form').serialize()
        };
    returned = wc_delete_status( data );
    if( returned == '1' ) {
        window.location = $(this).data('url');
    } else if( returned == '-1' ) {
        alert('Please choose another alternative term.');
    } else {
        alert('An error occurred. Please try again.');
    }
});

$('.status-icon-selector').click(function(){
    url = $(this).attr('src');
    fileName = url.substring(url.lastIndexOf('/') + 1);
    $('input[name="status_icon"]').val( fileName );
    $('.default-status-icon-selector').attr('src', url);
    jQuery('#TB_closeWindowButton').click()
});

$('.action-icon-selector').click(function(){
    url = $(this).attr('src');
    fileName = url.substring(url.lastIndexOf('/') + 1);
    $('input[name="action_icon"]').val( fileName );
    $('.default-action-icon-selector').attr('src', url);
    jQuery('#TB_closeWindowButton').click()
});

// Version 2.1
$('.action-icon-selector-21').click(function(){
    icon_uni = $(this).data('src');
    $('input[name="action_icon"]').val( icon_uni );
    $('.default-action-icon-selector').attr('class', 'button default-action-icon-selector tips woocommerce_status_action_font_icon woocommerce_status_actions_' + icon_uni);
    jQuery('#TB_closeWindowButton').click()
});

$('.status-icon-selector-21').click(function(){
    console.log("Setting");
    icon_uni = $(this).data('src');
    $('input[name="status_icon"]').val( icon_uni );
    $('.default-status-icon-selector').attr('class', 'default-status-icon-selector woocommerce_status_action_font_icon woocommerce_status_actions_' + icon_uni);
    jQuery('#TB_closeWindowButton').click()
});

}); // end of document ready